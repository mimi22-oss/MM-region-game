import {
  BoxGeometry,
  Group,
  InstancedMesh,
  Matrix4,
  Mesh,
  PlaneGeometry,
  Color,
  type BufferGeometry,
  type Material,
  type Object3D,
} from "three";

/** Batch opaque, immobile primitives by material and 128 m tile for culling. */
export function batchStaticMeshes(root: Group) {
  root.updateWorldMatrix(true, true);
  const inverse = root.matrixWorld.clone().invert(),
    unitBox = new BoxGeometry(1, 1, 1),
    unitPlane = new PlaneGeometry(1, 1);
  const groups = new Map<
    string,
    {
      geometry: BufferGeometry;
      material: Material;
      items: { mesh: Mesh; matrix: Matrix4 }[];
    }
  >();
  const materialKeys = new WeakMap<Material, string>();
  root.traverse((object) => {
    if (
      !(object instanceof Mesh) ||
      object instanceof InstancedMesh ||
      !object.visible ||
      Array.isArray(object.material)
    )
      return;
    for (let p: Object3D | null = object; p && p !== root; p = p.parent)
      if (p.userData.dynamic || !p.visible) return;
    const material = object.material;
    if (
      material.transparent ||
      !["MeshStandardMaterial", "MeshBasicMaterial"].includes(material.type)
    )
      return;
    let materialKey = materialKeys.get(material);
    if (!materialKey) {
      const json = material.toJSON();
      delete json.uuid;
      delete json.metadata;
      // Wall/roof paint belongs in instance colors, not a separate GPU draw call.
      delete json.color;
      materialKey = JSON.stringify(json);
      materialKeys.set(material, materialKey);
    }
    const geometry = object.geometry,
      parameters = (
        geometry as BufferGeometry & { parameters?: Record<string, number> }
      ).parameters;
    if (!parameters) return;
    const matrix = new Matrix4().multiplyMatrices(inverse, object.matrixWorld);
    let shape = geometry;
    if (geometry.type === "BoxGeometry") {
      shape = unitBox;
      matrix.multiply(
        new Matrix4().makeScale(
          parameters.width,
          parameters.height,
          parameters.depth,
        ),
      );
    } else if (
      geometry.type === "PlaneGeometry" &&
      (parameters.widthSegments ?? 1) === 1 &&
      (parameters.heightSegments ?? 1) === 1 &&
      !("map" in material && (material as { map?: unknown }).map)
    ) {
      shape = unitPlane;
      matrix.multiply(
        new Matrix4().makeScale(parameters.width, parameters.height, 1),
      );
    }
    const e = matrix.elements;
    const detail = shape === unitBox && !object.userData.walkable && matrix.getMaxScaleOnAxis() < 2.5 &&
      Math.min(Math.hypot(e[0],e[1],e[2]),Math.hypot(e[4],e[5],e[6]),Math.hypot(e[8],e[9],e[10]))<.3;
    const key = JSON.stringify([
      Math.floor(e[12] / 128),
      Math.floor(e[14] / 128),
      shape === unitBox ? "box" : shape === unitPlane ? "plane" : [geometry.type, parameters],
      detail,
      materialKey,
      object.castShadow,
      object.receiveShadow,
      object.renderOrder,
      Boolean(object.userData.walkable),
    ]);
    let group = groups.get(key);
    if (!group) {
      group = { geometry: shape, material, items: [] };
      groups.set(key, group);
    }
    group.items.push({ mesh: object, matrix });
  });
  const removed: { mesh: Mesh; parent: Object3D }[] = [],
    batches: InstancedMesh[] = [];
  for (const group of groups.values()) {
    if (group.items.length < 2) continue;
    const first = group.items[0].mesh;
    const batchMaterial=group.material.clone() as Material & {color:Color};
    batchMaterial.color.set('#ffffff');batchMaterial.userData={...batchMaterial.userData,shared:false};
    const
      batch = new InstancedMesh(
        group.geometry,
        batchMaterial,
        group.items.length,
      );
    batch.userData.walkable=Boolean(first.userData.walkable);
    batch.castShadow = first.castShadow;
    batch.receiveShadow = first.receiveShadow;
    batch.renderOrder = first.renderOrder;
    group.items.forEach(({ mesh, matrix }, i) => {
      batch.setMatrixAt(i, matrix);
      batch.setColorAt(i,(mesh.material as Material & {color:Color}).color);
      removed.push({ mesh, parent: mesh.parent! });
      mesh.removeFromParent();
    });
    batch.instanceMatrix.needsUpdate = true;
    if(batch.instanceColor)batch.instanceColor.needsUpdate=true;
    batch.updateMatrix();batch.matrixAutoUpdate=false;
    batch.computeBoundingBox();
    batch.computeBoundingSphere();
    batch.name = "static-tile";
    batch.userData.detail =
      group.geometry === unitBox &&
      !first.userData.walkable && group.items.every(({matrix})=>{
        const e=matrix.elements;return matrix.getMaxScaleOnAxis()<2.5&&Math.min(Math.hypot(e[0],e[1],e[2]),Math.hypot(e[4],e[5],e[6]),Math.hypot(e[8],e[9],e[10]))<.3;
      });
    root.add(batch);
    batches.push(batch);
  }
  // Batching removed the leaves. Remove their empty parent trees as well so
  // rendering, ground queries and camera rays do not visit thousands of empty groups.
  const emptyGroups: { group: Group; parent: Object3D }[] = [];
  function prune(parent: Object3D) {
    for (const child of [...parent.children]) {
      if (!(child instanceof Group) || child.userData.dynamic) continue;
      prune(child);
      if (child.children.length === 0) {
        emptyGroups.push({ group: child, parent });
        parent.remove(child);
      }
    }
  }
  prune(root);
  return {
    batches,
    sourceMeshes: removed.length,
    batchCount: batches.length,
    prunedGroups: emptyGroups.length,
    dispose() {
      for (const batch of batches) {
        root.remove(batch);
        batch.dispose();
      }
      for (const { group, parent } of [...emptyGroups].reverse()) parent.add(group);
      for (const { mesh, parent } of removed) parent.add(mesh);
      unitBox.dispose();
      unitPlane.dispose();
    },
  };
}
