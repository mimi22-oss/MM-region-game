export type CharacterKind = 'cartoon' | 'robot';
export const CHARACTER_STORAGE_KEY = 'myanmar-town.character';

export function savedCharacter(): CharacterKind {
 try { return localStorage.getItem(CHARACTER_STORAGE_KEY) === 'robot' ? 'robot' : 'cartoon'; }
 catch { return 'cartoon'; }
}

export function CharacterPicker({value,onChange,disabled=false}:{value:CharacterKind;onChange:(kind:CharacterKind)=>void;disabled?:boolean}) {
 return <fieldset className="character-picker" disabled={disabled}>
  <legend>ကစားမည့် ဇာတ်ကောင်</legend>
  <div className="character-options">
   <button type="button" aria-pressed={value==='cartoon'} onClick={()=>onChange('cartoon')}>
    <span className="character-swatch character-swatch-cartoon" aria-hidden="true"/>
    <span><strong>ဇာတ်ကောင်</strong></span>
   </button>
   <button type="button" aria-pressed={value==='robot'} onClick={()=>onChange('robot')}>
    <span className="character-swatch character-swatch-robot" aria-hidden="true"/>
    <span><strong>စက်ရုပ်</strong></span>
   </button>
  </div>
  <p>နှစ်မျိုးလုံးကို လက်ရှိနေရာမှာ ပြောင်းလဲရွေးချယ်နိုင်ပါတယ်။</p>
 </fieldset>;
}
