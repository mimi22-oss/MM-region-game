import { useEffect, useRef } from 'react';
import WardVillageEditor from './WardVillageEditor';
import type { Point2 } from '../game/worldLayout';
import './mapSelection.css';
import './WardVillageEditorDialog.css';

export default function WardVillageEditorDialog({ focus, onClose }: { focus: Point2; onClose: () => void }) {
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const node = dialog.current;
    if (!node) return;
    node.showModal();
    return () => { if (node.open) node.close(); };
  }, []);
  return (
    <dialog ref={dialog} className="map-selection-dialog ward-editor-dialog"
      aria-label="2D Map Editor" onCancel={event => { event.preventDefault(); onClose(); }}>
      <WardVillageEditor initialCenter={focus} onClose={onClose} />
    </dialog>
  );
}
