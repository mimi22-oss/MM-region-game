import {emptyLayout,loadLayout,validLayout,type LayoutFeature,type Point2,type WorldLayout,type FeatureKind} from './worldLayout';
export const REGIONS=[{id:'custom',name:'New / Custom Village'},{id:'myotha',name:'Myotha / မြို့သာ'},{id:'sitha',name:'Sitha / စည်သာ'},{id:'kanbale',name:'Kanbale / ကံပုလဲ'},{id:'natchaung',name:'Natchaung / နတ်ချောင်း'}];
const key=(id:string)=>`mm-editor-region-v1:${id}`;
export function loadRegionLayout(id:string):WorldLayout{
 if(id==='custom')return loadLayout();
 try{const raw=localStorage.getItem(key(id));if(raw){const data:unknown=JSON.parse(raw);if(validLayout(data))return data;}}catch{}
 return {...emptyLayout(),name:REGIONS.find(r=>r.id===id)?.name??id};
}
export function saveRegionLayout(id:string,layout:WorldLayout){
 if(id==='custom'){localStorage.setItem('myanmar-town-world-layout-v1',JSON.stringify(layout));}
 else localStorage.setItem(key(id),JSON.stringify(layout));
 window.dispatchEvent(new CustomEvent('world-layout-updated',{detail:{regionId:id,layout}}));
}
// GeoJSON import requires already projected local world X/Z coordinates.
// GPS lon/lat must first be transformed using the game's authoritative projection.
export function importGeoJSONFeatures(input:unknown):LayoutFeature[]{
 if(!input||typeof input!=='object')throw Error('Invalid GeoJSON');
 const root=input as {type?:string;features?:unknown[]};
 if(root.type!=='FeatureCollection'||!Array.isArray(root.features))throw Error('Expected FeatureCollection');
 const result:LayoutFeature[]=[];
 const point=(v:unknown):Point2=>{if(!Array.isArray(v)||v.length<2||!Number.isFinite(v[0])||!Number.isFinite(v[1]))throw Error('Invalid coordinates');const x=Number(v[0]),z=Number(v[1]);if(Math.abs(x)<=180&&Math.abs(z)<=90)throw Error('GPS lon/lat detected: project to world X/Z before import');return {x,z};};
 for(const item of root.features){
  const f=item as {id?:string|number;geometry?:{type?:string;coordinates?:unknown};properties?:Record<string,unknown>};
  const g=f?.geometry,p=f?.properties??{};if(!g)continue;
  let points:Point2[];let kind:FeatureKind;
  if(g.type==='Point'){points=[point(g.coordinates)];const raw=String(p.kind??p.type??p.amenity??p.building??'custom').toLowerCase();kind=raw.includes('school')?'school':raw.includes('hospital')?'hospital':raw.includes('tree')?'tree':raw.includes('shop')?'shop':raw.includes('house')||raw==='yes'?'house':'custom';}
  else if(g.type==='LineString'){points=(g.coordinates as unknown[]).map(point);kind='road';}
  else if(g.type==='Polygon'){points=((g.coordinates as unknown[][])[0]??[]).map(point);if(points.length>1&&points[0].x===points.at(-1)?.x&&points[0].z===points.at(-1)?.z)points.pop();kind=p.building?'house':p.boundary?'ward':'block';}
  else continue;
  if(!points.length||points.length>5000)continue;
  result.push({id:`geo-${String(f.id??crypto.randomUUID())}`,kind,name:String(p.name??p.label??kind),points,width:kind==='road'?Number(p.width)||5:undefined});
 }
 return result;
}
